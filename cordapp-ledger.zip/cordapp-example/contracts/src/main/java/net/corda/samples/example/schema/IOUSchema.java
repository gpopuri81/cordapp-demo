package net.corda.samples.example.schema;

/**
 * The family of schemas for IOUState.
 */
public class IOUSchema { }